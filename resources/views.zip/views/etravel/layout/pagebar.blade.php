<div class="page-bar">
	<ul class="page-breadcrumb">
		<li><i class="icon-home"></i> <a href="/etravel/dashboard">Home</a> <i
			class="fa fa-angle-right"></i></li>
		<li><span>{{ $breadcrumb }}</span></li>
	</ul>
</div>