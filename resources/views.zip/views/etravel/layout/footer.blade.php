 
<div class="page-wrapper-row">
    <div class="page-wrapper-bottom">
        <!-- BEGIN INNER FOOTER -->
        <div class="page-footer">
            <div class="container text-center"> Copyright © Arkema Corporation
                <a target="_blank" href="#">Communication &amp; Collaboration</a>
                All Rights Reserved 2018
            </div>
        </div>
        <div class="scroll-to-top" style="display: block;">
            <i class="fa fa-arrow-circle-o-up"></i>
        </div>
        <!-- END INNER FOOTER -->
        <!-- END FOOTER -->
    </div>
</div>